# TripWise Implementation

TripWise is a drive-vs-fly decision support prototype. It compares total driving cost and total flying cost, then recommends the better travel option based on cost, travel time, flexibility, and user preferences.

## How to run

1. Download the repository folder.
2. Open `code/index.html` in a modern browser.
3. Change the trip inputs and preference sliders.
4. Click **Calculate Recommendation**.

No server, database, or API key is required for this prototype version.

## Files

- `code/index.html` - main user interface
- `code/styles.css` - dashboard styling
- `code/app.js` - cost calculation and recommendation logic
- `docs/TripWise_Implementation_Document.docx` - functional decomposition, design flow, operational flow, screenshots, implementation details
- `planning/TripWise_Updated_Gantt_CriticalPath_PERT.xlsx` - updated schedule, critical path, and PERT planning
- `diagrams/` - flowcharts and PERT chart images
- `screenshots/` - implementation screenshots

## Current capabilities

- Accepts trip inputs
- Calculates driving costs
- Calculates flying costs
- Includes hidden costs
- Uses preference weighting
- Produces a drive/fly recommendation
- Shows hotel and pit stop suggestions
- Runs locally on another computer

## Future improvements

- Real Google Maps API integration
- Real flight API integration
- Real hotel and fuel price data
- Saved user profiles
- More detailed route planning
